#ifndef BLOCKLIST_H
#define BLOCKLIST_H


#include <Arduino.h>
#include "hash_table.h"


extern DomainHashTable blockedDomains;
struct ImportResult
{
    int added = 0;
    int duplicates = 0;
    int ignored = 0;
};

void loadBlocklist();
void saveBlocklist();

bool addBlockedDomain(String domain);
bool removeBlockedDomain(String domain);

String createBlocklistJSON();

bool isBlocked(String domain);

ImportResult importBlocklist(String data);
int getBlocklistSize();
void clearBlocklist();
String normalizeDomain(String line);

#endif